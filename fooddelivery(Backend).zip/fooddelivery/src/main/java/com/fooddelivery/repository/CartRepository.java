package com.fooddelivery.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fooddelivery.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Long> {

}
