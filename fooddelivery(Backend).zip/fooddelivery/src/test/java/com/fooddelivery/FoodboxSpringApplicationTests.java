package com.fooddelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodboxSpringApplicationTests {

	@Test
	void contextLoads() {
	}

   @Test
   public void getUsername() {
	  System.out.print("Getuser name Method Works");
   }
   
   @Test
   public void getPassword() {
	   System.out.println("Get password works fine....");
   }
   @Test
   public void getId() {
	   System.out.println("GetId Works");
   }
}